document.addEventListener("DOMContentLoaded", () => {
    const boardElement = document.getElementById("board");
    const totalCells = 100;
    let cells = [];
    
    // Create board cells (from 100 down to 1)
    for (let i = totalCells; i >= 1; i--) {
      const cell = document.createElement("div");
      cell.classList.add("cell");
      cell.dataset.number = i;
      cell.innerHTML = `<span>${i}</span>`;
      boardElement.appendChild(cell);
      cells[i] = cell;
    }
    
    // UI elements
    const rollButton = document.getElementById("rollButton");
    const diceResult = document.getElementById("diceResult");
    const turnInfo = document.getElementById("turnInfo");
    const messageEl = document.getElementById("message");
    const playerListDiv = document.getElementById("playerList");
    
    // Connect to Socket.io
    const socket = io();
    
    // Prompt for player's name and join the snake game
    const playerName = prompt("Enter your name for Snake & Ladders:");
    if (playerName) {
      socket.emit("joinSnakeGame", { name: playerName });
    }
    
    // Update board tokens for each player
    function updateBoard(gameState) {
      // Remove previous tokens
      document.querySelectorAll(".player-token").forEach(token => token.remove());
      // For each player, if position > 0, add token to corresponding cell
      gameState.players.forEach((player, idx) => {
        if (player.position > 0) {
          const cell = cells[player.position];
          if (cell) {
            const token = document.createElement("div");
            token.classList.add("player-token");
            token.style.backgroundColor = player.color;
            token.style.width = "20px";
            token.style.height = "20px";
            token.style.borderRadius = "50%";
            token.style.position = "absolute";
            // Offset tokens so they don't overlap completely (adjust index)
            token.style.top = `${idx * 22}px`;
            token.style.left = "5px";
            cell.appendChild(token);
          }
        }
      });
    }
    
    // Update footer to show list of players with their colors
    function updatePlayerList(gameState) {
      playerListDiv.innerHTML = ""; // Clear previous list
      gameState.players.forEach(player => {
        const pDiv = document.createElement("div");
        pDiv.classList.add("px-2", "py-1", "rounded", "shadow", "text-sm");
        pDiv.style.backgroundColor = player.color;
        pDiv.style.color = "#fff";
        pDiv.textContent = player.name;
        playerListDiv.appendChild(pDiv);
      });
    }
    
    // Update turn info
    function updateTurnInfo(gameState) {
      if (gameState.players.length > 0) {
        const currentPlayer = gameState.players[gameState.currentTurnIndex];
        turnInfo.textContent = `Current Turn: ${currentPlayer.name}`;
      }
    }
    
    // Listen for game state updates from the server
    socket.on("snakeGameUpdate", (gameState) => {
      updateBoard(gameState);
      updatePlayerList(gameState);
      updateTurnInfo(gameState);
      diceResult.textContent = ""; // Clear dice result message
      // Check win condition
      gameState.players.forEach(player => {
        if (player.position === 100) {
          messageEl.textContent = `${player.name} wins!`;
          rollButton.disabled = true;
        }
      });
    });
    
    // Listen for individual dice roll result (optional)
    socket.on("diceRolled", (data) => {
      diceResult.textContent = `${data.dice} rolled, moved to ${data.newPos}`;
    });
    
    // When the roll button is clicked, emit a rollDice event
    rollButton.addEventListener("click", () => {
      socket.emit("rollDice");
    });
  });
  