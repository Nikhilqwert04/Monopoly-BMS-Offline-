// =========================
// Tab Switching Functionality
// =========================
document.querySelectorAll('.tabs button').forEach(button => {
  button.addEventListener('click', () => {
    document.querySelectorAll('.tabs button').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    button.classList.add('active');
    const tabId = button.getAttribute('data-tab');
    document.getElementById(tabId).classList.add('active');
  });
});

// =========================
// Socket.io Client Code
// =========================
const socket = io();
let onlinePlayers = [];
let currentBalance = 0; // For tracking wallet balance

// =========================
// Sound Effects
// =========================
const audioCountryBought = new Audio('/sounds/countryBought.WAV');
const audioHouseBuilt = new Audio('/sounds/houseBuilt.WAV');
const audioMoneyReceived = new Audio('/sounds/moneyReceived.WAV');
const audioMoneySent = new Audio('/sounds/moneySent.WAV');
const audioOtherSounds = new Audio('/sounds/otherSounds.WAV');

// Function to show a transient notification at bottom left.
function showNotification(text) {
  const notification = document.createElement('div');
  notification.classList.add('notification');
  notification.textContent = text;
  document.body.appendChild(notification);
  window.getComputedStyle(notification).opacity; // Force reflow
  notification.style.opacity = 1;
  setTimeout(() => {
    notification.style.opacity = 0;
    setTimeout(() => {
      notification.remove();
    }, 500);
  }, 2500);
}

// Listen for money notifications
socket.on('moneyNotification', (data) => {
  const sign = data.amount < 0 ? '' : '+';
  showNotification(`${sign}$${Math.abs(data.amount)} (${data.source})`);
});

// -------------------------
// Player Join and Updates
// -------------------------
const playerName = prompt("Enter your player name:");
if (!playerName) {
  alert("You must enter a name to join!");
} else {
  socket.emit('joinGame', { playerName });
}

socket.on('playerJoined', (player) => {
  document.getElementById('playerName').textContent = player.name;
  document.getElementById('playerBalance').textContent = player.balance;
  document.getElementById('playerId').textContent = player._id;
  currentBalance = player.balance;
});

socket.on('onlinePlayers', (players) => {
  onlinePlayers = players;
  console.log('Online Players:', onlinePlayers);
});

// -------------------------
// Display Available Countries
// -------------------------
socket.on('countriesList', (countries) => {
  const countryListEl = document.getElementById('countryList');
  countryListEl.innerHTML = '';
  countries.forEach(country => {
    const li = document.createElement('li');
    li.innerHTML = `<strong>${country.name}</strong> - Price: $${country.price} - Base Rent: $${country.baseRent}`;
    
    // Create a "Buy" button with a confirmation dialog.
    const buyButton = document.createElement('button');
    buyButton.textContent = 'Buy';
    buyButton.addEventListener('click', (e) => {
      e.stopPropagation();
      // Show confirmation dialog.
      if (confirm(`Are you sure you want to buy ${country.name} for $${country.price}?`)) {
        const playerId = document.getElementById('playerId').textContent;
        socket.emit('buyCountry', { playerId, countryId: country._id });
        // Play a sound effect for buying a country.
        audioCountryBought.play();
      }
    });
    
    li.appendChild(buyButton);
    countryListEl.appendChild(li);
  });
});


// -------------------------
// Display Owned Countries with Details
// -------------------------
socket.on('ownedCountries', (ownedCountries) => {
  const ownedCountryListEl = document.getElementById('ownedCountryList');
  ownedCountryListEl.innerHTML = '';
  ownedCountries.forEach(country => {
    const li = document.createElement('li');
    li.style.cursor = 'pointer';
    const mortgagedLabel = country.mortgaged ? ' <span style="color:red; font-weight:bold;">[MORTGAGED]</span>' : '';
    li.innerHTML = `<div style="text-align:center; font-weight:bold;">${country.name}${mortgagedLabel}</div>`;
    li.addEventListener('click', () => {
      const existingDetails = li.querySelector('.country-details');
      if (existingDetails) {
        existingDetails.remove();
        return;
      }
      const detailsDiv = document.createElement('div');
      detailsDiv.classList.add('country-details');

      // Houses / Hotel Indicator
      const housesDiv = document.createElement('div');
      housesDiv.style.textAlign = 'center';
      if (country.hotel) {
        const hotelLabel = document.createElement('div');
        hotelLabel.textContent = "Hotel Built";
        hotelLabel.style.fontWeight = 'bold';
        hotelLabel.style.color = '#d35400';
        housesDiv.appendChild(hotelLabel);
      } else {
        for (let i = 0; i < (country.houses || 0); i++) {
          const img = document.createElement('img');
          img.src = 'images.png';
          img.alt = 'House';
          img.style.width = '30px';
          img.style.margin = '2px';
          housesDiv.appendChild(img);
        }
      }
      detailsDiv.appendChild(housesDiv);

      // Country Name
      const nameDiv = document.createElement('div');
      nameDiv.style.textAlign = 'center';
      nameDiv.style.fontSize = '20px';
      nameDiv.style.fontWeight = 'bold';
      nameDiv.style.color = country.color;
      nameDiv.textContent = country.name;
      detailsDiv.appendChild(nameDiv);

      // Country Price
      const priceDiv = document.createElement('div');
      priceDiv.style.textAlign = 'center';
      priceDiv.textContent = `Price: $${country.price}`;
      detailsDiv.appendChild(priceDiv);

      // Rents List
      const rentsDiv = document.createElement('div');
      rentsDiv.style.marginTop = '10px';
      rentsDiv.style.textAlign = 'left';
      const rentInfo = [
        `Base Rent: $${country.baseRent}`,
        `Rent with 1 House: $${country.rent1}`,
        `Rent with 2 Houses: $${country.rent2}`,
        `Rent with 3 Houses: $${country.rent3}`,
        `Rent with 4 Houses: $${country.rent4}`,
        `Hotel Rent: ${country.hotel ? '$' + country.hotelRent : '-' }`
      ];
      rentInfo.forEach((line, index) => {
        const p = document.createElement('p');
        p.textContent = line;
        if (index === 5 && country.hotel) {
          p.style.fontWeight = 'bold';
        }
        rentsDiv.appendChild(p);
      });
      detailsDiv.appendChild(rentsDiv);

      // Build House Button
      if (!country.hotel && (country.houses || 0) < 4) {
        const buildHouseBtn = document.createElement('button');
        buildHouseBtn.textContent = `Build House ($${country.houseCost})`;
        buildHouseBtn.classList.add('detail-btn');
        buildHouseBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          // Confirmation before building a house.
        if (confirm(`Are you sure you want to build a house for $${country.houseCost}?`)) {
          const playerId = document.getElementById('playerId').textContent;
          socket.emit('buildHouse', { playerId, countryId: country._id });
          audioHouseBuilt.play();
        }
      });
        detailsDiv.appendChild(buildHouseBtn);
      }
      if (!country.hotel && (country.houses || 0) === 4) {
        const buildHotelBtn = document.createElement('button');
        buildHotelBtn.textContent = `Build Hotel ($${country.houseCost})`;
        buildHotelBtn.classList.add('detail-btn');
        buildHotelBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          const playerId = document.getElementById('playerId').textContent;
          socket.emit('buildHotel', { playerId, countryId: country._id });
          audioHouseBuilt.play();
        });
        detailsDiv.appendChild(buildHotelBtn);
      }

      // Request Rent Button
      const requestRentBtn = document.createElement('button');
      requestRentBtn.textContent = 'Request Rent';
      requestRentBtn.classList.add('detail-btn');
      requestRentBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const rentAmount = prompt("Enter the rent amount to request:");
        if (!rentAmount || isNaN(rentAmount) || parseInt(rentAmount, 10) <= 0) {
          alert("Please enter a valid rent amount.");
          return;
        }
        const myId = document.getElementById('playerId').textContent;
        let selectionUI = document.createElement('div');
        selectionUI.classList.add('selection-ui');
        selectionUI.innerHTML = "<strong>Select a visitor:</strong><br/>";
        onlinePlayers.filter(p => p._id !== myId).forEach(p => {
          const btn = document.createElement('button');
          btn.textContent = p.name;
          btn.addEventListener('click', (ev) => {
            ev.stopPropagation();
            socket.emit('requestRent', {
              fromPlayerId: p._id,
              toPlayerId: myId,
              countryId: country._id,
              customRent: parseInt(rentAmount, 10)
            });
            alert(`Rent request of $${rentAmount} sent to ${p.name}`);
            selectionUI.remove();
          });
          selectionUI.appendChild(btn);
        });
        detailsDiv.appendChild(selectionUI);
      });
      detailsDiv.appendChild(requestRentBtn);
      
      // Mortgage / Redeem Mortgage Button
      const mortgageBtn = document.createElement('button');
      if (!country.mortgaged) {
        mortgageBtn.textContent = 'Mortgage';
        mortgageBtn.classList.add('detail-btn');
        mortgageBtn.addEventListener('click', (e) => {
          e.stopPropagation();
        if (confirm(`Are you sure you want to mortgage ${country.name}?`)) {
          const playerId = document.getElementById('playerId').textContent;
          socket.emit('mortgageCountry', { playerId, countryId: country._id });
        }
      });
      } else {
        mortgageBtn.textContent = 'Redeem Mortgage';
        mortgageBtn.classList.add('detail-btn');
        mortgageBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          const playerId = document.getElementById('playerId').textContent;
          socket.emit('redeemMortgage', { playerId, countryId: country._id });
          audioOtherSounds.play();
        });
      }
      detailsDiv.appendChild(mortgageBtn);
      
      // Chest Deduction Button
      const chestDeductionBtnPanel = document.createElement('button');
      chestDeductionBtnPanel.textContent = 'Chest Deduction';
      chestDeductionBtnPanel.classList.add('detail-btn');
      chestDeductionBtnPanel.addEventListener('click', (e) => {
        e.stopPropagation();
        const amount = prompt("Enter the amount to deduct (Chest Card):");
        if (!amount || isNaN(amount) || parseInt(amount, 10) <= 0) {
          alert("Please enter a valid amount.");
          return;
        }
        const playerId = document.getElementById('playerId').textContent;
        socket.emit('deductMoney', { playerId, amount });
        audioOtherSounds.play();
      });
      detailsDiv.appendChild(chestDeductionBtnPanel);
      
      li.appendChild(detailsDiv);
    });
    ownedCountryListEl.appendChild(li);
  });
});

// Get references to the profile image and file input elements.
const profileImage = document.getElementById('profileImage');
const profileImageInput = document.getElementById('profileImageInput');

// When the profile image is clicked, trigger the hidden file input.
if (profileImage && profileImageInput) {
  profileImage.addEventListener('click', () => {
    profileImageInput.click();
  });

  // When a file is selected, update the profile image.
  profileImageInput.addEventListener('change', (event) => {
    const file = event.target.files[0];
    if (file) {
      // Use FileReader to read the file as a Data URL.
      const reader = new FileReader();
      reader.onload = (e) => {
        profileImage.src = e.target.result;
        // Optionally, you can emit an event to save the profile image on the server.
        // socket.emit('updateProfileImage', { playerId: document.getElementById('playerId').textContent, imageData: e.target.result });
      };
      reader.readAsDataURL(file);
    }
  });
}


// -------------------------
// Refresh Owned Countries on Update
// -------------------------
socket.on('countryUpdated', (updatedCountry) => {
  console.log('Country updated:', updatedCountry);
  const playerId = document.getElementById('playerId').textContent;
  socket.emit('getOwnedCountries', { playerId });
});

socket.on('playerUpdated', (player) => {
  document.getElementById('playerBalance').textContent = player.balance;
  currentBalance = player.balance;
});

// -------------------------
// Rent Request (for visitors)
// -------------------------
socket.on('rentRequest', (data) => {
  const message = `You are requested to pay rent of $${data.customRent} for country ${data.countryId}. Click OK to pay.`;
  if (confirm(message)) {
    socket.emit('payRent', {
      fromPlayerId: data.fromPlayerId,
      toPlayerId: data.toPlayerId,
      countryId: data.countryId,
      rentAmount: data.customRent
    });
  }
});

// =========================
// Manager Tab Dashboard
// =========================
function updateManagerTab() {
  // Request all owned countries from the server.
  socket.emit('getAllOwnedCountries');
  
  // Use socket.once to listen for a one-time response.
  socket.once('allOwnedCountries', (countries) => {
    const managerTab = document.getElementById('managerTab');
    managerTab.innerHTML = ''; // Clear existing content

    // Create header for Manager Dashboard.
    const header = document.createElement('h2');
    header.textContent = 'Manager Dashboard';
    managerTab.appendChild(header);

    // --- Section 1: Give Money ---
    const giveMoneySection = document.createElement('div');
    giveMoneySection.classList.add('manager-section');
    giveMoneySection.innerHTML = '<h3>Give Money</h3>';
    
    // Create a select dropdown with online players.
    const selectPlayer = document.createElement('select');
    onlinePlayers.forEach(p => {
      const option = document.createElement('option');
      option.value = p._id;
      option.textContent = p.name;
      selectPlayer.appendChild(option);
    });
    giveMoneySection.appendChild(selectPlayer);
    
    // Create an input for the amount.
    const amountInput = document.createElement('input');
    amountInput.type = 'number';
    amountInput.placeholder = 'Amount';
    giveMoneySection.appendChild(amountInput);
    
    // Create the "Give Money" button.
    const giveMoneyBtn = document.createElement('button');
    giveMoneyBtn.textContent = 'Give Money';
    giveMoneyBtn.addEventListener('click', () => {
      const targetPlayerId = selectPlayer.value;
      const amount = amountInput.value;
      if (!amount || parseInt(amount, 10) <= 0) {
        alert('Please enter a valid amount.');
        return;
      }
      socket.emit('managerGiveMoney', { playerId: targetPlayerId, amount });
      alert(`$${amount} given to the selected player.`);
      // Play send money sound since manager is sending money.
      audioMoneySent.play();
      updateManagerTab(); // Refresh dashboard after money is given.
    });
    giveMoneySection.appendChild(giveMoneyBtn);
    managerTab.appendChild(giveMoneySection);

    // --- Section 2: Result ---
    const resultSection = document.createElement('div');
    resultSection.classList.add('manager-section');
    resultSection.innerHTML = '<h3>Result</h3>';
    const resultBtn = document.createElement('button');
    resultBtn.textContent = 'Calculate Result';
    resultBtn.addEventListener('click', () => {
      socket.emit('calculateResult');
    });
    resultSection.appendChild(resultBtn);
    managerTab.appendChild(resultSection);

    // --- Section 3: Confiscate Country ---
    const confiscateSection = document.createElement('div');
    confiscateSection.classList.add('manager-section');
    confiscateSection.innerHTML = '<h3>Confiscate Country</h3>';
    if (countries.length === 0) {
      confiscateSection.innerHTML += '<p>No countries are currently owned.</p>';
    } else {
      const ul = document.createElement('ul');
      countries.forEach(country => {
        // Assume that country.owner is populated.
        const li = document.createElement('li');
        li.innerHTML = `<strong>${country.name}</strong> (Owner: ${country.owner ? country.owner.name : 'Unknown'})`;
        li.style.cursor = 'pointer';
        li.addEventListener('click', () => {
          if (confirm(`Confiscate ${country.name} from owner ${country.owner.name}? \nThe owner will receive 50% of its price as compensation.`)) {
            socket.emit('makeCountryAvailable', { countryId: country._id, playerId: country.owner._id });
            alert(`${country.name} has been confiscated.`);
            // Play received money sound since the owner is getting compensated.
            audioMoneyReceived.play();
            updateManagerTab(); // Refresh dashboard after confiscation.
          }
        });
        ul.appendChild(li);
      });
      confiscateSection.appendChild(ul);
    }
    managerTab.appendChild(confiscateSection);
  });
}

// -------------------------
// Manager Panel Trigger
// -------------------------
const managerBtn = document.getElementById('managerBtn');
if (managerBtn) {
  managerBtn.addEventListener('click', () => {
    const pwd = prompt("Enter Manager Password:");
    if (pwd) {
      socket.emit('managerLogin', { password: pwd });
    }
  });
}

socket.on('managerLoginSuccess', () => {
  // Optionally, show the Manager Tab button.
  const managerTabBtn = document.getElementById('managerTabBtn');
  if (managerTabBtn) {
    managerTabBtn.style.display = 'inline-block';
  }
  updateManagerTab();
});

socket.on('managerLoginFailure', (data) => {
  alert(data.message);
});

// Refresh Manager Tab when country ownership changes.
socket.on('countryBought', () => {
  updateManagerTab();
});
socket.on('countryUpdated', () => {
  updateManagerTab();
});

// -------------------------
// Global Result Broadcast (from manager calculation)
// -------------------------
socket.on('resultCalculated', (message) => {
  const resultModal = document.getElementById('resultModal');
  document.getElementById('resultText').textContent = message;
  resultModal.style.display = 'block';
  setTimeout(() => {
    resultModal.style.display = 'none';
  }, 3000);
});

// -------------------------
// Global Chest Deduction Button (Bottom Right)
// -------------------------
const chestDeductionBtn = document.getElementById('chestDeductionBtn');
if (chestDeductionBtn) {
  chestDeductionBtn.addEventListener('click', () => {
    const amount = prompt("Enter the amount to deduct from your balance:");
    const playerId = document.getElementById('playerId').textContent;
    if (amount && parseInt(amount, 10) > 0) {
      socket.emit('deductMoney', { playerId, amount });
    } else {
      alert("Invalid amount entered.");
    }
  });
};

// -------------------------
// Transaction History Button (opens new tab)
// -------------------------
const historyBtn = document.getElementById('historyBtn');
historyBtn.addEventListener('click', () => {
  const playerId = document.getElementById('playerId').textContent;
  window.open(`transactionHistory.html?playerId=${playerId}`, '_blank');

});


// -------------------------
// Global Money Notification Handler
// -------------------------
socket.on('moneyNotification', (data) => {
  const sign = data.amount < 0 ? '' : '+';
  showNotification(`${sign}$${Math.abs(data.amount)} (${data.source})`);
  // If money is added (positive amount), play moneyReceived audio;
  // if money is subtracted (negative amount), play moneySent audio.
  if (data.amount > 0) {
    audioMoneyReceived.play();
  } else if (data.amount < 0) {
    audioMoneySent.play();
  }
});
