const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const mongoose = require('mongoose');
const path = require('path');
const crypto = require('crypto');

// Import models (ensure these files exist and export the corresponding Mongoose models)
const Player = require('./models/Player');
const Country = require('./models/Country');
const Transaction = require('./models/Transaction');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Generate a manager password and log it for testing.
const managerPassword = crypto.randomBytes(4).toString('hex');
console.log('Manager Password:', managerPassword);

// Connect to MongoDB.
mongoose.connect("mongodb+srv://admin:admin123123@mono.e70zjoc.mongodb.net/?retryWrites=true&w=majority&appName=mono")
  .then(() => console.log('MongoDB Connected'))
  .catch(err => console.error('MongoDB Connection Error:', err));

// Serve static files from the "public" folder.
app.use(express.static(path.join(__dirname, 'public')));

// Fallback route: serve monopoly.html for unmatched routes.
app.get('/', (req, res) => {
  res.sendFile(path.resolve(__dirname, 'public', 'index.html'));
});


// -------------------------
// Seed sample countries with new fields
// -------------------------
async function seedCountries() {
  const countries = [
    {
      name: 'Northumberland Avenue',
      price: 160,
      color: '#B6375C',
      baseRent: 12,
      rent1: 60,
      rent2: 180,
      rent3: 500,
      rent4: 700,
      hotelRent: 1500,
      houseCost: 50
    },
    {
      name: 'Park Lane',
      price: 350,
      color: '#275B8A',
      baseRent: 35,
      rent1: 175,
      rent2: 500,
      rent3: 1100,
      rent4: 1300,
      hotelRent: 2000,
      houseCost: 150
    },
    {
      name: 'Bow Street',
      price: 180,
      color: '#D26E2E',
      baseRent: 14,
      rent1: 70,
      rent2: 200,
      rent3: 550,
      rent4: 750,
      hotelRent: 2000,
      houseCost: 50
    },
    {
      name: 'The Angel',
      price: 100,
      color: '#91A8B7',
      baseRent: 6,
      rent1: 30,
      rent2: 90,
      rent3: 270,
      rent4: 400,
      hotelRent: 1200,
      houseCost: 50
    },
    {
      name: 'Pentonville Road',
      price: 120,
      color: '#91A8B7',
      baseRent: 8,
      rent1: 40,
      rent2: 100,
      rent3: 300,
      rent4: 450,
      hotelRent: 1500,
      houseCost: 50
    },
    {
      name: 'Euston Road',
      price: 100,
      color: '#91A8B7',
      baseRent: 6,
      rent1: 30,
      rent2: 90,
      rent3: 270,
      rent4: 400,
      hotelRent: 1200,
      houseCost: 50
    },
    {
      name: 'Mayfair',
      price: 400,
      color: '#275B8A',
      baseRent: 50,
      rent1: 200,
      rent2: 600,
      rent3: 1400,
      rent4: 1700,
      hotelRent: 2500,
      houseCost: 200
    },
    {
      name: 'Marlborough Street',
      price: 180,
      color: '#D26E2E',
      baseRent: 14,
      rent1: 70,
      rent2: 200,
      rent3: 550,
      rent4: 750,
      hotelRent: 2000,
      houseCost: 50
    },
    {
      name: 'Vine Street',
      price: 200,
      color: '#D26E2E',
      baseRent: 16,
      rent1: 80,
      rent2: 220,
      rent3: 600,
      rent4: 800,
      hotelRent: 2200,
      houseCost: 100
    },
    {
      name: 'Pall Mall',
      price: 140,
      color: '#B6375C',
      baseRent: 10,
      rent1: 50,
      rent2: 150,
      rent3: 450,
      rent4: 625,
      hotelRent: 1500,
      houseCost: 50
    },
    {
      name: 'Whitehall',
      price: 140,
      color: '#B6375C',
      baseRent: 10,
      rent1: 50,
      rent2: 150,
      rent3: 450,
      rent4: 625,
      hotelRent: 1500,
      houseCost: 50
    },
    {
      name: 'Strand',
      price: 220,
      color: '#BC2E3D',
      baseRent: 18,
      rent1: 90,
      rent2: 250,
      rent3: 700,
      rent4: 875,
      hotelRent: 1800,
      houseCost: 100
    },
    {
      name: 'Trafalgar Square',
      price: 240,
      color: '#BC2E3D',
      baseRent: 20,
      rent1: 100,
      rent2: 300,
      rent3: 750,
      rent4: 925,
      hotelRent: 2000,
      houseCost: 100
    },
    {
      name: 'Fleet Street',
      price: 240,
      color: '#BC2E3D',
      baseRent: 18,
      rent1: 90,
      rent2: 250,
      rent3: 700,
      rent4: 875,
      hotelRent: 2000,
      houseCost: 100
    },
    {
      name: 'Coventry Road',
      price: 260,
      color: '#CBA400',
      baseRent: 22,
      rent1: 110,
      rent2: 330,
      rent3: 800,
      rent4: 975,
      hotelRent: 2200,
      houseCost: 100
    },
    {
      name: 'Piccadilly',
      price: 280,
      color: '#CBA400',
      baseRent: 24,
      rent1: 120,
      rent2: 360,
      rent3: 850,
      rent4: 1025,
      hotelRent: 2400,
      houseCost: 100
    },
    {
      name: 'Leicester Square',
      price: 260,
      color: '#CBA400',
      baseRent: 22,
      rent1: 110,
      rent2: 330,
      rent3: 800,
      rent4: 975,
      hotelRent: 2200,
      houseCost: 100
    },
    {
      name: 'Oxford Street',
      price: 300,
      color: '#466435',
      baseRent: 26,
      rent1: 130,
      rent2: 390,
      rent3: 900,
      rent4: 1100,
      hotelRent: 2500,
      houseCost: 150
    },
    {
      name: 'Regent Street',
      price: 300,
      color: '#466435',
      baseRent: 26,
      rent1: 130,
      rent2: 390,
      rent3: 900,
      rent4: 1100,
      hotelRent: 2500,
      houseCost: 150
    },
    {
      name: 'Bond Street',
      price: 320,
      color: '#466435',
      baseRent: 28,
      rent1: 150,
      rent2: 450,
      rent3: 1000,
      rent4: 1200,
      hotelRent: 2600,
      houseCost: 150
    },
    {
      name: 'Old Kent Road',
      price: 60,
      color: '#7D403B',
      baseRent: 2,
      rent1: 10,
      rent2: 30,
      rent3: 90,
      rent4: 160,
      hotelRent: 800,
      houseCost: 50
    },
    {
      name: 'Whitechapel Road',
      price: 60,
      color: '#7D403B',
      baseRent: 4,
      rent1: 20,
      rent2: 60,
      rent3: 180,
      rent4: 320,
      hotelRent: 800,
      houseCost: 50
    },
    {
      name: 'Water Works',
      price: 150,
      color: '#7E5C49',
      baseRent: 1,
      rent1: 0,
      rent2: 0,
      rent3: 0,
      rent4: 0,
      hotelRent: 0,
      houseCost: 0
    },
    {
      name: 'Electric Company',
      price: 150,
      color: '#7E5C49',
      baseRent: 1,
      rent1: 0,
      rent2: 0,
      rent3: 0,
      rent4: 0,
      hotelRent: 0,
      houseCost: 0
    },
    {
      name: 'Fenchurch Railway',
      price: 200,
      color: '#393737',
      baseRent: 25,
      rent1: 50,
      rent2: 100,
      rent3: 200,
      rent4: 200,
      hotelRent: 0,
      houseCost: 0
    },
    {
      name: 'Marylebone Railway',
      price: 200,
      color: '#393737',
      baseRent: 25,
      rent1: 50,
      rent2: 100,
      rent3: 200,
      rent4: 200,
      hotelRent: 0,
      houseCost: 0
    },
    {
      name: 'Liverpool Railway',
      price: 200,
      color: '#393737',
      baseRent: 25,
      rent1: 50,
      rent2: 100,
      rent3: 200,
      rent4: 200,
      hotelRent: 0,
      houseCost: 0
    },
    {
      name: 'Kings Cross Railway',
      price: 200,
      color: '#393737',
      baseRent: 25,
      rent1: 50,
      rent2: 100,
      rent3: 200,
      rent4: 200,
      hotelRent: 0,
      houseCost: 0
    }
  ];

  for (const country of countries) {
    await Country.updateOne(
      { name: country.name },
      {
        ...country,
        owner: null,
        houses: 0,
        hotel: false,
        mortgaged: false
      },
      { upsert: true }
    );
  }
  console.log('✅ Countries seeded/updated');
}


// --- Snake & Ladders Multiplayer Game ---
let snakeGame = {
  players: [],         // Array of player objects: { socketId, name, position, color }
  currentTurnIndex: 0  // Index in the players array for whose turn it is
};

const colors = ["red", "blue", "green", "yellow", "purple", "orange"];

io.on('connection', (socket) => {
  console.log("Socket connected:", socket.id);
  
  // When a player joins the Snake game
  socket.on('joinSnakeGame', (data) => {
    // Create a new player object and assign a color from the list
    const newPlayer = {
      socketId: socket.id,
      name: data.name,
      position: 0,
      color: colors[snakeGame.players.length % colors.length]
    };
    snakeGame.players.push(newPlayer);
    socket.join("snakeGame");
    // Broadcast updated game state to all players in the snakeGame room
    io.to("snakeGame").emit("snakeGameUpdate", snakeGame);
  });
  
  // When a player rolls the dice
  socket.on('rollDice', () => {
    // Ensure it's this player's turn
    if (!snakeGame.players.length) return;
    if (snakeGame.players[snakeGame.currentTurnIndex].socketId !== socket.id) {
      socket.emit("errorMessage", { message: "Not your turn!" });
      return;
    }
    // Roll a dice (1-6)
    const dice = Math.floor(Math.random() * 6) + 1;
    
    // Update the current player's position
    let currentPlayer = snakeGame.players[snakeGame.currentTurnIndex];
    let newPos = currentPlayer.position + dice;
    if (newPos > 100) {
      newPos = currentPlayer.position; // Do not move if beyond 100
    }
    
    // Define snakes and ladders mappings
    const snakes = { 16: 6, 47: 26, 49: 11, 56: 53, 62: 19, 64: 60, 87: 24, 93: 73, 95: 75, 98: 78 };
    const ladders = { 2: 38, 7: 14, 8: 31, 15: 26, 21: 42, 28: 84, 36: 44, 51: 67, 71: 91 };
    
    if (ladders[newPos]) {
      newPos = ladders[newPos];
    } else if (snakes[newPos]) {
      newPos = snakes[newPos];
    }
    
    currentPlayer.position = newPos;
    
    // Check for win condition
    let win = false;
    if (newPos === 100) {
      win = true;
    }
    
    // Advance turn if no win
    if (!win) {
      snakeGame.currentTurnIndex = (snakeGame.currentTurnIndex + 1) % snakeGame.players.length;
    }
    
    // Emit updated game state to all players in "snakeGame" room
    io.to("snakeGame").emit("snakeGameUpdate", snakeGame);
    // Optionally, send a dice roll result event to the rolling player
    socket.emit("diceRolled", { dice, newPos, win });
  });
  
  // When a player disconnects, remove them from the game
  socket.on('disconnect', () => {
    const index = snakeGame.players.findIndex(p => p.socketId === socket.id);
    if (index !== -1) {
      snakeGame.players.splice(index, 1);
      // Adjust currentTurnIndex if necessary
      if (snakeGame.currentTurnIndex >= snakeGame.players.length) {
        snakeGame.currentTurnIndex = 0;
      }
      io.to("snakeGame").emit("snakeGameUpdate", snakeGame);
    }
    console.log("Socket disconnected:", socket.id);
  });
});

// (No country seeding code is added here)

let onlinePlayers = {};

io.on('connection', (socket) => {
  console.log('A user connected');

  // -------------------------
  // Manager/Confiscation Related Events
  // -------------------------
  socket.on('getAllOwnedCountries', async () => {
    try {
      // Find all countries that have an owner; populate the owner field.
      const ownedCountries = await Country.find({ owner: { $ne: null } }).populate('owner');
      socket.emit('allOwnedCountries', ownedCountries);
    } catch (err) {
      console.error('Error getting all owned countries:', err);
      socket.emit('error', { message: 'Failed to get all owned countries' });
    }
  });

  socket.on('makeCountryAvailable', async (data) => {
    try {
      // data must include: countryId and playerId (the owner's id)
      const country = await Country.findOne({ _id: data.countryId, owner: data.playerId });
      if (!country) {
        return socket.emit('error', { message: 'Country not found or not owned by specified player.' });
      }
      // Calculate compensation: 50% of the country's price.
      const compensation = Math.floor(country.price * 0.5);
      country.owner = null;
      await country.save();
      const player = await Player.findById(data.playerId);
      if (player) {
        player.balance += compensation;
        await player.save();
        io.to(player._id.toString()).emit('playerUpdated', player);
        io.to(player._id.toString()).emit('moneyNotification', { amount: compensation, source: "Confiscation Compensation" });
      }
      // Update available countries list.
      const countries = await Country.find({ owner: null });
      io.emit('countriesList', countries);
      socket.emit('countryUpdated', country);
    } catch (err) {
      console.error('Error making country available:', err);
      socket.emit('error', { message: 'Failed to make country available' });
    }
  });

  // -------------------------
  // Player Join and Updates
  // -------------------------
  socket.on('joinGame', async (data) => {
    try {
      let player = await Player.findOne({ name: data.playerName });
      if (!player) {
        player = new Player({ name: data.playerName });
        await player.save();
      }
      onlinePlayers[player._id.toString()] = { _id: player._id, name: player.name };
      socket.join(player._id.toString());
      socket.emit('playerJoined', player);
      const ownedCountries = await Country.find({ owner: player._id });
      socket.emit('ownedCountries', ownedCountries);
      const countries = await Country.find({ owner: null });
      socket.emit('countriesList', countries);
      io.emit('onlinePlayers', Object.values(onlinePlayers));
    } catch (error) {
      console.error('Error joining game:', error);
      socket.emit('error', { message: 'Failed to join game' });
    }
  });
  
  socket.on('getOwnedCountries', async (data) => {
    try {
      const ownedCountries = await Country.find({ owner: data.playerId });
      socket.emit('ownedCountries', ownedCountries);
    } catch (error) {
      console.error('Error fetching owned countries:', error);
      socket.emit('error', { message: 'Failed to get owned countries' });
    }
  });
  
  // -------------------------
  // Manager Login and Money Events
  // -------------------------
  socket.on('managerLogin', (data) => {
    console.log("Manager login attempt with password:", data.password);
    if (data.password === managerPassword) {
      console.log("Manager login success");
      socket.emit('managerLoginSuccess');
    } else {
      console.log("Manager login failure");
      socket.emit('managerLoginFailure', { message: 'Incorrect Password' });
    }
  });

  socket.on('managerGiveMoney', async (data) => {
    try {
      const targetPlayer = await Player.findById(data.playerId);
      if (!targetPlayer) throw new Error('Player not found');
      targetPlayer.balance += parseInt(data.amount, 10);
      await targetPlayer.save();
      io.to(targetPlayer._id.toString()).emit('playerUpdated', targetPlayer);
      io.to(targetPlayer._id.toString()).emit('moneyNotification', { amount: data.amount, source: "Manager" });
      socket.emit('managerActionSuccess', { message: `Gave $${data.amount} to ${targetPlayer.name}` });
    } catch (err) {
      console.error('Manager action error:', err);
      socket.emit('error', { message: 'Manager action failed' });
    }
  });
  
  socket.on('calculateResult', async () => {
    try {
      const players = await Player.find({}).populate('ownedCountries');
      let results = [];
      players.forEach(player => {
        let total = player.balance;
        player.ownedCountries.forEach(country => {
          total += country.price;
          if (country.hotel) {
            total += country.hotelRent;
          } else {
            total += (country.houses || 0) * country.houseCost;
          }
        });
        results.push({ name: player.name, total });
      });
      let max = results[0];
      results.forEach(r => {
        if (r.total > max.total) {
          max = r;
        }
      });
      const message = `Result: ${max.name} wins with total assets of $${max.total}`;
      io.emit('resultCalculated', message);
    } catch (error) {
      console.error('Error calculating result:', error);
      socket.emit('error', { message: 'Failed to calculate result' });
    }
  });
  
  // -------------------------
  // Money Deduction Event
  // -------------------------
  socket.on('deductMoney', async (data) => {
    try {
      const player = await Player.findById(data.playerId);
      if (!player) throw new Error('Player not found');
      const amount = parseInt(data.amount, 10);
      if (player.balance >= amount) {
        player.balance -= amount;
        await player.save();
        socket.emit('playerUpdated', player);
        io.to(player._id.toString()).emit('moneyNotification', { amount: -amount, source: "Deduction" });
      } else {
        socket.emit('error', { message: 'Insufficient funds for deduction' });
      }
    } catch (err) {
      console.error('Deduction error:', err);
      socket.emit('error', { message: 'Deduction failed' });
    }
  });
  
  // -------------------------
  // Buy Country Event
  // -------------------------
  socket.on('buyCountry', async (data) => {
    try {
      const player = await Player.findById(data.playerId);
      const country = await Country.findById(data.countryId);
      if (!player || !country) throw new Error('Player or country not found');
      if (player.balance >= country.price) {
        player.balance -= country.price;
        country.owner = player._id;
        player.ownedCountries.push(country._id);
        await player.save();
        await country.save();
        socket.emit('playerUpdated', player);
        const countries = await Country.find({ owner: null });
        io.emit('countriesList', countries);
        const ownedCountries = await Country.find({ owner: player._id });
        socket.emit('ownedCountries', ownedCountries);
        io.emit('countryBought', { player, country });
      } else {
        socket.emit('error', { message: 'Insufficient balance' });
      }
    } catch (error) {
      console.error('Error buying country:', error);
      socket.emit('error', { message: 'Failed to buy country' });
    }
  });
  
  // -------------------------
  // Build House Event
  // -------------------------
  socket.on('buildHouse', async (data) => {
    try {
      const player = await Player.findById(data.playerId);
      const country = await Country.findById(data.countryId);
      if (!player || !country) throw new Error('Player or country not found');
      if (country.hotel) {
        return socket.emit('error', { message: 'Hotel already built; cannot build houses' });
      }
      if ((country.houses || 0) >= 4) {
        return socket.emit('error', { message: 'Maximum houses built on this country' });
      }
      if (player.balance >= country.houseCost) {
        player.balance -= country.houseCost;
        country.houses = (country.houses || 0) + 1;
        await player.save();
        await country.save();
        socket.emit('countryUpdated', country);
        socket.emit('playerUpdated', player);
      } else {
        socket.emit('error', { message: 'Insufficient funds to build a house' });
      }
    } catch (error) {
      console.error('Error building house:', error);
      socket.emit('error', { message: 'Failed to build house' });
    }
  });
  
  // -------------------------
  // Build Hotel Event
  // -------------------------
  socket.on('buildHotel', async (data) => {
    try {
      const player = await Player.findById(data.playerId);
      const country = await Country.findById(data.countryId);
      if (!player || !country) throw new Error('Player or country not found');
      if (country.hotel) {
        return socket.emit('error', { message: 'Hotel already built' });
      }
      if ((country.houses || 0) < 4) {
        return socket.emit('error', { message: 'Need 4 houses to build a hotel' });
      }
      if (player.balance >= country.houseCost) {
        player.balance -= country.houseCost;
        country.hotel = true;
        country.houses = 0;
        await player.save();
        await country.save();
        socket.emit('countryUpdated', country);
        socket.emit('playerUpdated', player);
      } else {
        socket.emit('error', { message: 'Insufficient funds to build a hotel' });
      }
    } catch (error) {
      console.error('Error building hotel:', error);
      socket.emit('error', { message: 'Failed to build hotel' });
    }
  });
  
  // -------------------------
  // Mortgage Country Event
  // -------------------------
  socket.on('mortgageCountry', async (data) => {
    try {
      const player = await Player.findById(data.playerId);
      const country = await Country.findById(data.countryId);
      if (!player || !country) throw new Error('Player or country not found');
      if (country.mortgaged) {
        return socket.emit('error', { message: 'Country is already mortgaged' });
      }
      const mortgageValue = Math.floor(country.price / 2);
      player.balance += mortgageValue;
      country.mortgaged = true;
      await player.save();
      await country.save();
      socket.emit('playerUpdated', player);
      socket.emit('countryUpdated', country);
      io.to(player._id.toString()).emit('moneyNotification', { amount: mortgageValue, source: "Mortgage" });
    } catch (error) {
      console.error('Error mortgaging country:', error);
      socket.emit('error', { message: 'Failed to mortgage country' });
    }
  });
  
  // -------------------------
  // Redeem Mortgage Event
  // -------------------------
  socket.on('redeemMortgage', async (data) => {
    try {
      const player = await Player.findById(data.playerId);
      const country = await Country.findById(data.countryId);
      if (!player || !country) throw new Error('Player or country not found');
      if (!country.mortgaged) {
        return socket.emit('error', { message: 'Country is not mortgaged' });
      }
      const mortgageValue = Math.floor(country.price / 2);
      const redemptionCost = Math.floor(mortgageValue * 1.1);
      if (player.balance < redemptionCost) {
        return socket.emit('error', { message: 'Insufficient funds to redeem mortgage' });
      }
      player.balance -= redemptionCost;
      country.mortgaged = false;
      await player.save();
      await country.save();
      socket.emit('playerUpdated', player);
      socket.emit('countryUpdated', country);
    } catch (error) {
      console.error('Error redeeming mortgage:', error);
      socket.emit('error', { message: 'Failed to redeem mortgage' });
    }
  });
  
  // -------------------------
  // Rent Request Event
  // -------------------------
  socket.on('requestRent', async (data) => {
    try {
      io.to(data.fromPlayerId).emit('rentRequest', data);
    } catch (error) {
      console.error('Error requesting rent:', error);
      socket.emit('error', { message: 'Failed to request rent' });
    }
  });
  
  // -------------------------
  // Rent Payment Event
  // -------------------------
  socket.on('payRent', async (data) => {
    try {
      const fromPlayer = await Player.findById(data.fromPlayerId);
      const toPlayer = await Player.findById(data.toPlayerId);
      const country = await Country.findById(data.countryId);
      if (!fromPlayer || !toPlayer || !country) throw new Error('Player or country not found');
      const rentAmount = data.rentAmount;
      if (fromPlayer.balance >= rentAmount) {
        fromPlayer.balance -= rentAmount;
        toPlayer.balance += rentAmount;
        await fromPlayer.save();
        await toPlayer.save();
        const transaction = new Transaction({
          fromPlayer: fromPlayer._id,
          toPlayer: toPlayer._id,
          amount: rentAmount,
          description: `Rent for ${country.name}`,
        });
        await transaction.save();
        socket.emit('playerUpdated', fromPlayer);
        io.to(toPlayer._id.toString()).emit('playerUpdated', toPlayer);
        io.emit('rentPaid', { fromPlayer, toPlayer, country, rentAmount });
        io.to(toPlayer._id.toString()).emit('moneyNotification', { amount: rentAmount, source: `Rent from ${fromPlayer.name}` });
      } else {
        socket.emit('error', { message: 'Insufficient balance to pay rent' });
      }
    } catch (error) {
      console.error('Error paying rent:', error);
      socket.emit('error', { message: 'Failed to pay rent' });
    }
  });
  
  socket.on('disconnect', () => {
    console.log('User disconnected');
    // Optionally, remove player from onlinePlayers.
  });
  
  // -------------------------
  // Reset Game via Console Command
  // -------------------------
  process.stdin.resume();
  process.stdin.setEncoding('utf8');
  process.stdin.on('data', async (data) => {
    const input = data.trim();
    if (input === 'reset') {
      try {
        await Player.deleteMany({});
        await Transaction.deleteMany({});
        await Country.updateMany({}, { owner: null, houses: 0, mortgaged: false, hotel: false });
        console.log('Game has been reset.');
      } catch (err) {
        console.error('Error resetting game:', err);
      }
    }
  });
});

server.listen(3000, () => {
  console.log('Listening on *:3000');
});
