const mongoose = require('mongoose');

const transactionSchema = new mongoose.Schema({
  fromPlayer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Player'
  },
  toPlayer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Player'
  },
  amount: {
    type: Number,
    required: true,
    min: 0
  },
  description: {
    type: String,
    required: true,
    trim: true
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Transaction', transactionSchema);