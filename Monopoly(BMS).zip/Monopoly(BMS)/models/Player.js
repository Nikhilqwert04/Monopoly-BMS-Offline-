const mongoose = require('mongoose');

const playerSchema = new mongoose.Schema({
    name: { type: String, required: true, unique: true },
    balance: { type: Number, default: 1500 }, // Starting balance
    ownedCountries: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Country' }],
});

module.exports = mongoose.model('Player', playerSchema);