const mongoose = require('mongoose');

const countrySchema = new mongoose.Schema({
  name: { type: String, required: true, unique: true },
  price: { type: Number, required: true },
  color: { type: String, required: true },
  baseRent: { type: Number, required: true },      // Base rent when no house is built
  rent1: { type: Number, required: true },           // Rent when 1 house is built
  rent2: { type: Number, required: true },           // Rent when 2 houses are built
  rent3: { type: Number, required: true },           // Rent when 3 houses are built
  rent4: { type: Number, required: true },           // Rent when 4 houses are built
  hotelRent: { type: Number, required: true },       // Rent when a hotel is built
  houseCost: { type: Number, required: true },       // Cost to build one house (or hotel)
  houses: { type: Number, default: 0 },              // Number of houses built
  hotel: { type: Boolean, default: false },          // Whether a hotel is built
  mortgaged: { type: Boolean, default: false },      // Whether the property is mortgaged
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'Player', default: null }
});

module.exports = mongoose.model('Country', countrySchema);
